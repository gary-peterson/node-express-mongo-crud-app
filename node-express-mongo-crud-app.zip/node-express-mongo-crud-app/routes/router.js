/*
	router.js
*/

const 
	DefsMiddleware = require('../middlewares/defs-middleware.js').DefsMiddleware,
	DefMiddleware = require('../middlewares/def-middleware.js').DefMiddleware,		
	SearchMiddleware = require('../middlewares/search-middleware.js').SearchMiddleware,			
	CommonMiddleware = require('../middlewares/common-middleware.js').CommonMiddleware;			

class Router {
	
	static setupRoutes(app) {
		this.setupCommonRoutes(app);
		this.setupDefsRoutes(app);
		this.setupDefRoutes(app);		
		this.setupSearchRoutes(app);
	}
	
	static setupCommonRoutes(app) {
		app.get("/", CommonMiddleware.getHomePage);
		app.post("/action/cancel", CommonMiddleware.cancelAction);				
		app.get("/homePage", CommonMiddleware.getHomePage);						
		app.post("/homePage", CommonMiddleware.getHomePage);								
	}	
		
	static setupDefsRoutes(app) {
		//routes for defs
		//multiple action callbacks run in order
		app.get("/defs", 
			DefsMiddleware.readAll,
			DefsMiddleware.getDefsPage);
	}
	
	static setupDefRoutes(app) {
		//routes for def
		app.get("/def/new", DefMiddleware.getCreatePage);
		app.post("/def/create", DefMiddleware.create);
		app.get("/defs/:id/edit", DefMiddleware.getEditPage);
		app.put("/defs/:id/update", DefMiddleware.update);		
		app.delete("/defs/:id/delete", DefMiddleware.delete);				
	}
	
	static setupSearchRoutes(app) {
		//routes for searching defs
		app.get("/defs/searchPage", SearchMiddleware.getResultsPage);
		app.post("/defs/search", 
			SearchMiddleware.search,
			SearchMiddleware.getResultsPage);			
	}	
	

		
}

//---------------------------------------------------

exports.Router = Router;	
