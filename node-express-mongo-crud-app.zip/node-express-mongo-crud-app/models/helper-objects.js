//helper-objects.js

/* not needed in initializeApp()
	//var bodyParser = require('body-parser');
	//app.use(bodyParser.json());		
*/

const
	express = require("express"),	
	log = console.log,
	override = require("method-override"),
	CommonMiddleware = require('../middlewares/common-middleware.js').CommonMiddleware;				
		
/*	
	router = express.Router(),		
	connectFlash = require("connect-flash"),
	expressValidator = require("express-validator"),
	expressSession = require("express-session"),
	cookieParser = require("cookie-parser");
*/	

//-------------------------------------	

class DbTools {
	
	static saveHandler(fieldName) {
		//Display "fieldName" of object on success
		return (error, savedDoc) => {
			if (error) log(error);
			else log(`Saved model (doc) -- "${savedDoc[fieldName]}"`);
		};
	}
}

//-------------------------------------

class AppStartupTools {
	
	static initializeApp(app) {
		//default init
		app.use(express.urlencoded({extended: false}));
		app.use(override("_method", {methods: ["POST", "GET"]}));
		app.use(express.json());
		app.use(CommonMiddleware.logRequest);
		app.set("port", process.env.PORT || 3000);
		app.set("view engine", "ejs");
		//sets "public" as root of static resources
		app.use(express.static("public"));				
	}

}

//-------------------------------------

exports.DbTools = DbTools;
exports.AppStartupTools = AppStartupTools;
