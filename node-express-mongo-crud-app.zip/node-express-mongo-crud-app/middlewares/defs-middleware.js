/*defs-middleware.js
	
Middleware for collection of defs (defintions)
*/

const 
	Def = require('../models/def'),
	DbTools = require('../models/helper-objects').DbTools;
	
//---------------------------------------------------	

class DefsMiddleware {
	
	//------------------------------------------
	//DB Queries
	
	static readAll(req, res, next) {
		//get all defs and assign to request
		Def.find({}, (error, defs) => {
			if (error) next(error);
			req.data = defs;
			next();
		});
	}
	
	//------------------------------------------
	//Serving (Responding)
	
	static getDefsPage(req, res, next) {
		/*defs-list.ejs" is name of EJS file 
		Second arg is assoc for var name (defs) in EJS file*/
		res.render("defs/list", {defs: req.data});
	};	
		
};

//---------------------------------------------------

exports.DefsMiddleware = DefsMiddleware;
