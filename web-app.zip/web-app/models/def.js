/*def.js
	
	def = definition or quick definition
*/

const 
	mongoose = require("mongoose"),
	emptyArrayAsJson = () => JSON.stringify([]);	

const defSchema = mongoose.Schema({
	name: {
		type: String,
		required: [true, 'Name is required']
		},
	text: {
		type: String,
		required: [true, 'Definition is required']
	}
});

//-------------------------------------

//NOTE -- mongoose requires traditional fct format here
defSchema.statics.blankObject = function() {
	//Initial (blank) model
	return {
		name: null, 
		text: null, 
		errors: emptyArrayAsJson()
	}
}

//NOTE -- mongoose requires traditional fct format here
defSchema.methods.asObject = function(errorsList) {
	//Initial (blank) model
	return {
		name: this.name, 
		text: this.text, 
		errors: [errorsList ? errorsList : emptyArrayAsJson]
	}
}

//-------------------------------------
//Convenience class (ideally the above would be a class but mongooose does not support)

//class Def {
//}

//-------------------------------------

//This syntax allows "Def" to be the default export
module.exports = mongoose.model('Def', defSchema);