//db-connector.js

const 
	mongoose = require("mongoose"),
	log = console.log;

class DbConnector {
	
	constructor(uri) {
		this.uri = uri;
		this.db = null;
	}
	
	connect() {
		mongoose.set('useNewUrlParser', true);
		mongoose.set('useUnifiedTopology', true);
		mongoose.set('useFindAndModify', false);
		mongoose.connect(this.uri);
		this.db = mongoose.connection;
		this.db.once("open", () => {
			log("Success connecting to database");
		});		
	}
	
}


//------------------------------------------------

exports.DbConnector = DbConnector;	