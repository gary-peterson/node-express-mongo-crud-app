/*
	main.js
	
	Note: "this.constructor" refers to the class
*/

const 
	mongoose = require("mongoose"),
	Def = require('./def'),
	log = console.log,
	DbTools = require('./helper-objects').DbTools;

class Loader1 {
	
	static async assureSeeded() {
		//async means this method is asynchronous (caller perspective)
		//await means we wait for the called method to complete
		const count = await Def.countDocuments();
		//If no defs, then load initial "seed data"		
		if (count === 0)
			this.loadSeededData();
	}
	
	static loadSeededData() {
		const data =
			[['functional endpoint', 'function that handles a request via a URL'],
			['url endpoint', 'Path component of URL used to route the request'],
			['api', 'agreement between software provider (coder) and software consumer on how function will be called'],
			['api provider', 'Software that answers an API call'],
			['api consumer', 'Software that calls an API and consumes/uses the result'],			
			['synchronous', 'Waits for a task to complete (the task is blocking).'],
			['asynchronous', 'No waiting for task to complete (the task is non-blocking)']];
		for (let eachData of data) {
			const def = new Def({
				name: eachData[0],
				text: eachData[1]});
			def.save(DbTools.saveHandler('name'));
		}
	}
	
}
	
//------------------------------------------------

exports.Loader1 = Loader1;
	
