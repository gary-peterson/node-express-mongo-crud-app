/*search-defs-middleware.js
	
Middleware for searching defs
*/

const 
	Def = require('../models/def'),
	DbTools = require('../models/helper-objects').DbTools,
	log = console.log;
	
//---------------------------------------------------	

class SearchMiddleware {
	
	static search(req, res, next) {
		const searchString = req.body.searchString ?? '';
		var regex = new RegExp(searchString, 'i');
		//Def.find({name: regex, text: regex}, (error, results) => {
		Def.find({$or: [{name: regex}, {text: regex}]}, (error, results) => {
			if (error) next(error);
			req.data = results;
			next();
		});
	}	
	
	static getResultsPage(req, res, next) {
		//"??" is "nullish coalescing operator"
		res.render('defs/search',
					{results: req.data ?? [],
					searchString: ''});	
	}
	
};

//---------------------------------------------------

exports.SearchMiddleware = SearchMiddleware;
