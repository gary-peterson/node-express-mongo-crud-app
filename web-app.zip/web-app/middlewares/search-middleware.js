/*search-defs-middleware.js
	
Middleware for searching defs
*/

const 
	Def = require('../models/def'),
	DbTools = require('../models/helper-objects').DbTools,
	log = console.log;
	
//==========================================================
//helper functions

const searchData = (searchResults, searchString) => {
	return {
		results: searchResults ?? [],
		searchString: searchString ?? ''
	};
}

	
const findNameOrText = (searchString) => {
	const regex = new RegExp(searchString, 'i');		
	return Def.find({$or: [{name: regex}, {text: regex}]}).exec();
}	
	
//==========================================================
//public (exported class)

class SearchMiddleware {
	
	static async search(req, res, next) {
		const 
			str = req.body.searchString ?? '',
			results = await findNameOrText(str);
		res.render('defs/search', searchData(results, str));
	}
		
	static getResultsPage(req, res, next) {
		//"??" is "nullish coalescing operator"
		res.render('defs/search', searchData());
	}	
	
}

//==========================================================

exports.SearchMiddleware = SearchMiddleware;

