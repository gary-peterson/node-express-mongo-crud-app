/*def-middleware.js
	
Middleware for one def (defintion)
*/

const 
	Def = require('../models/def'),
	DbTools = require('../models/helper-objects').DbTools,
	log = console.log;
	
//---------------------------------------------------	

class DefMiddleware {
	
	
	static getCreatePage(req, res, next) {
		//def is name of view (EJS file)
		res.render('def/create', Def.blankObject());
		next();
	}	
	
	static create(req, res, next) {
		//"req.body.name" is from HTML form (see def.ejs)
		const def = new Def({
			name: req.body.name,
			text: req.body.text			
		});
		def.save()
			.then(result => res.render('success'))
			.catch(validationError => {
				const errors = DefMiddleware.messagesFromValidationError(validationError);
				//stringify (deflate) for transfer to client
				res.render('def/create', def.asObject(JSON.stringify(errors)));
			});
	}

	static messagesFromValidationError(validationError) {
		const messages = [];
		const errs = validationError.errors;
		for (var errName in errs)
			messages.push(errs[errName].message);
		return messages;
	}
	
	
	static getEditPage(req, res, next) {
		const id = req.params.id;
		Def.findById(id)
			.then(def => {
				const params = def.asObject(JSON.stringify([]));
				params.def = def;
				res.render("def/edit", params);
			}).catch(err => {
				log(`Error finding def by ID: ${err.message}`);
				next(err);
			});
	}
			
	static update(req, res, next) {
		const id = req.params.id;
		const input = {
			name: req.body.name, 
			text: req.body.text};
		Def.findByIdAndUpdate(id, {$set: input})
			.then(def => {
				res.redirect('/defs')	
				next();
			}).catch(err => {
				log(`Error updating item: ${err.message}`);
			});
	}
	
	static delete(req, res, next) {
		const id = req.params.id;
		Def.findByIdAndRemove(id)
			.then(def => {
				res.redirect('/defs')	
				next();
			}).catch(err => {
				log(`Error deleting item: ${err.message}`);
			});
	}	
	
}

//---------------------------------------------------

exports.DefMiddleware = DefMiddleware;
