
//common-middleware.js

//---------------------------------------------------	

const log = console.log;
	
//---------------------------------------------------	

class CommonMiddleware {
	
	static logRequest(req, res, next) {
		//middleware function (helpful for debugging)
		log(`Request received: ${req.url}`);
		log(`Request method: ${req.method}`);
		log(`Request Body: ${JSON.stringify(req.body)}`);		
		next();
	}		
	
	static getHomePage(req, res) {
		//"index" is name of view (EJS file)
		res.render("index");
	}
	
	static cancelAction(req, res, next) {
		res.redirect('/')	
		next();		
	}	
	
};

//---------------------------------------------------

exports.CommonMiddleware = CommonMiddleware;
