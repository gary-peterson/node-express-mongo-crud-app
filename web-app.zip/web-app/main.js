/*
main.js

npm install express mongoose ejs express-ejs-layouts method-override

http://localhost:3000

*/

const 
	app = require("express")(),
	Router = require('./routes/router').Router,
	AppStartupTools = require('./models/helper-objects').AppStartupTools,
	log = console.log,
	layouts = require("express-ejs-layouts");	
	
const 
	DbConnector = require('./models/db-connector.js').DbConnector,
	dbUri = 'mongodb://localhost:27017/quick_def_db',
	Loader1 = require('./models/loader1.js').Loader1;	
	
//----------------------------------
//app setup

AppStartupTools.initializeApp(app);
Router.setupRoutes(app);

//----------------------------------
//connect to db and load any initial "seed" data

const dbConnector = new DbConnector(dbUri);	
dbConnector.connect();		
Loader1.assureSeeded();
	
//----------------------------------
//start web server app

app.listen(app.get("port"), () => {
  log(`server running on ${app.get("port")}`);
});		














